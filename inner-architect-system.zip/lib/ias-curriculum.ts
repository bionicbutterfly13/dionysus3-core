import type { Phase, Lesson } from './ias-types';

// Complete Inner Architect System Curriculum
// This can be replaced with Neo4j fetches in production

export const IAS_CURRICULUM: Phase[] = [
  {
    id: 'phase-1',
    name: 'Revelation',
    subtitle: 'Awareness',
    description: 'Uncover the hidden patterns, beliefs, and stories that shape your reality. This phase is about seeing clearly what has been operating beneath the surface.',
    color: '#3B82F6', // Blue
    lessons: [
      {
        id: 'lesson-1',
        name: 'Breakthrough Basics',
        subtitle: 'Self-Awareness',
        description: 'Identify the patterns, beliefs, and stories that drive your behavior.',
        actions: [
          {
            id: 'action-1-1',
            name: 'Choose patterns to address',
            description: 'Identify which recurring patterns in your life need attention.',
            transformation: 'From scattered awareness to focused clarity on what matters most.',
            obstacles: [
              { id: 'obs-1-1-1', name: 'Overwhelm in identifying priorities', description: 'Too many patterns compete for attention.' },
              { id: 'obs-1-1-2', name: 'Fear of flaw exposure', description: 'Resistance to seeing your own blind spots.' },
              { id: 'obs-1-1-3', name: 'Limited self-assessment practice', description: 'Lack of tools for honest self-reflection.' },
            ],
          },
          {
            id: 'action-1-2',
            name: 'Pinpoint beliefs',
            description: 'Uncover the deep-seated beliefs driving your choices.',
            transformation: 'From unconscious reaction to conscious understanding of your motivations.',
            obstacles: [
              { id: 'obs-1-2-1', name: 'Subconscious beliefs are hard to access', description: 'Deep beliefs operate below awareness.' },
              { id: 'obs-1-2-2', name: 'Resistance to questioning success-linked assumptions', description: 'Fear of disrupting what seems to work.' },
              { id: 'obs-1-2-3', name: 'Difficulty linking behaviors to beliefs', description: 'The connection feels abstract or unclear.' },
            ],
          },
          {
            id: 'action-1-3',
            name: 'Notice stories + impact',
            description: 'Recognize the narratives you tell yourself and measure their effect.',
            transformation: 'From being ruled by stories to observing them with perspective.',
            obstacles: [
              { id: 'obs-1-3-1', name: 'Personal and cultural narratives feel invisible', description: 'Stories are so embedded they seem like truth.' },
              { id: 'obs-1-3-2', name: 'Assessing narrative impact feels abstract', description: 'Hard to measure something so intangible.' },
              { id: 'obs-1-3-3', name: 'Strong emotions distort self-reflection', description: 'Feelings cloud objective observation.' },
            ],
          },
        ],
      },
      {
        id: 'lesson-2',
        name: 'MOSAEIC Method',
        subtitle: 'Mental Agility',
        description: 'Learn to observe your thoughts, emotions, and behaviors under pressure.',
        actions: [
          {
            id: 'action-2-1',
            name: 'Choose context to improve under pressure',
            description: 'Select a high-stakes area where you want to perform better.',
            transformation: 'From scattered effort to targeted improvement in what matters.',
            obstacles: [
              { id: 'obs-2-1-1', name: 'Too many competing high-pressure areas', description: 'Everything feels urgent and important.' },
              { id: 'obs-2-1-2', name: 'Pressure to be effective everywhere', description: 'Fear of neglecting any area.' },
              { id: 'obs-2-1-3', name: 'Unclear which area to prioritize', description: 'Lack of criteria for choosing.' },
            ],
          },
          {
            id: 'action-2-2',
            name: 'Apply MOSAEIC technique',
            description: 'Practice observing thoughts, emotions, and behaviors objectively.',
            transformation: 'From being swept up in reactions to becoming a conscious observer.',
            obstacles: [
              { id: 'obs-2-2-1', name: 'Adopting new practices amid busyness', description: 'No time or space for new habits.' },
              { id: 'obs-2-2-2', name: 'Objectivity challenged by performance mindset', description: 'Hard to observe when trying to perform.' },
              { id: 'obs-2-2-3', name: 'Difficulty maintaining observation consistency', description: 'Forgetting to practice in the moment.' },
            ],
          },
          {
            id: 'action-2-3',
            name: 'Track impact of stories',
            description: 'Monitor how your internal narratives affect decisions and outcomes.',
            transformation: 'From blind influence to measured understanding of story impact.',
            obstacles: [
              { id: 'obs-2-3-1', name: 'Narratives are hard to observe in real time', description: 'Stories operate too fast to catch.' },
              { id: 'obs-2-3-2', name: 'Subtle decision biases go unnoticed', description: 'Small influences compound invisibly.' },
              { id: 'obs-2-3-3', name: 'Outcome attribution feels speculative', description: 'Hard to prove cause and effect.' },
            ],
          },
        ],
      },
      {
        id: 'lesson-3',
        name: 'Replay Loop Breaker',
        subtitle: 'Empowerment',
        description: 'Break free from mental replays that keep you stuck in frustration.',
        actions: [
          {
            id: 'action-3-1',
            name: 'Spot the story behind your most frustrating replay pattern',
            description: 'Identify the narrative fueling your mental loops.',
            transformation: 'From endless replay to understanding the story driving it.',
            obstacles: [
              { id: 'obs-3-1-1', name: 'Vulnerability in facing discomfort', description: 'Looking at painful patterns is hard.' },
              { id: 'obs-3-1-2', name: 'Root beliefs are complex to uncover', description: 'Layers of meaning obscure the core.' },
              { id: 'obs-3-1-3', name: 'Risk of harsh self-judgment', description: 'Fear of being too critical of yourself.' },
            ],
          },
          {
            id: 'action-3-2',
            name: 'Label the feeling the story causes you to experience',
            description: 'Name the emotion connected to your replay pattern.',
            transformation: 'From vague distress to precise emotional clarity.',
            obstacles: [
              { id: 'obs-3-2-1', name: 'Emotional overwhelm during prioritization', description: 'Feelings flood when you try to focus.' },
              { id: 'obs-3-2-2', name: 'Ambiguity around "which belief matters most"', description: 'Multiple beliefs seem equally relevant.' },
              { id: 'obs-3-2-3', name: 'Interconnected beliefs cloud focus', description: 'Everything seems connected to everything.' },
            ],
          },
          {
            id: 'action-3-3',
            name: 'Identify the protective prediction the replay is trying to fulfill',
            description: 'Understand what your mind is trying to protect you from.',
            transformation: 'From feeling attacked by your mind to understanding its protective intent.',
            obstacles: [
              { id: 'obs-3-3-1', name: 'Deep beliefs feel too big to break down', description: 'Core beliefs seem monolithic.' },
              { id: 'obs-3-3-2', name: 'Origins are emotionally charged', description: 'The source material is painful.' },
              { id: 'obs-3-3-3', name: 'Motivation dips without quick wins', description: 'Progress feels too slow to sustain.' },
            ],
          },
        ],
      },
    ],
  },
  {
    id: 'phase-2',
    name: 'Repatterning',
    subtitle: 'Change',
    description: 'Transform limiting beliefs into empowering ones. This phase is about actively rewiring the mental patterns that no longer serve you.',
    color: '#10B981', // Green
    lessons: [
      {
        id: 'lesson-4',
        name: 'Conviction Gauntlet',
        subtitle: 'Hope',
        description: 'Challenge and transform your limiting beliefs through rigorous examination.',
        actions: [
          {
            id: 'action-4-1',
            name: 'Review beliefs + stories',
            description: 'Examine your prioritized limiting beliefs and their associated narratives.',
            transformation: 'From avoiding painful truths to facing them with compassion.',
            obstacles: [
              { id: 'obs-4-1-1', name: 'Revisiting pain can retraumatize', description: 'Old wounds reopen when examined.' },
              { id: 'obs-4-1-2', name: 'Difficulty staying neutral', description: 'Emotions override objective analysis.' },
              { id: 'obs-4-1-3', name: 'Insights can feel disjointed', description: 'Hard to see the coherent picture.' },
            ],
          },
          {
            id: 'action-4-2',
            name: 'Analyze origins + evidence',
            description: 'Investigate where your beliefs came from and what supports them.',
            transformation: 'From accepting beliefs as truth to questioning their foundations.',
            obstacles: [
              { id: 'obs-4-2-1', name: 'Resistance to challenging identity beliefs', description: 'These beliefs feel like who you are.' },
              { id: 'obs-4-2-2', name: 'Difficulty separating facts from assumptions', description: 'What seems true may be interpretation.' },
              { id: 'obs-4-2-3', name: 'Confirmation bias strengthens old beliefs', description: 'You find evidence for what you already believe.' },
            ],
          },
          {
            id: 'action-4-3',
            name: 'Develop/test new beliefs',
            description: 'Create and experiment with empowering alternative beliefs.',
            transformation: 'From knowing only one way to having new possibilities to test.',
            obstacles: [
              { id: 'obs-4-3-1', name: 'New beliefs may not feel believable', description: 'Affirmations can feel hollow.' },
              { id: 'obs-4-3-2', name: "Life doesn't immediately reflect change", description: 'Results lag behind internal shifts.' },
              { id: 'obs-4-3-3', name: 'Setbacks may reinforce old patterns', description: 'Failures seem to prove old beliefs right.' },
            ],
          },
        ],
      },
      {
        id: 'lesson-5',
        name: 'Perspective Matrix',
        subtitle: 'Insight',
        description: 'Expand your viewpoint by exploring multiple perspectives.',
        actions: [
          {
            id: 'action-5-1',
            name: 'Identify/analyze perspective',
            description: 'Recognize your current viewpoint and its limitations.',
            transformation: 'From assuming your view is complete to seeing its boundaries.',
            obstacles: [
              { id: 'obs-5-1-1', name: 'Self-bias is hard to catch', description: 'Your perspective feels like objectivity.' },
              { id: 'obs-5-1-2', name: 'Owning limitations threatens self-image', description: 'Admitting gaps feels vulnerable.' },
              { id: 'obs-5-1-3', name: 'Multiview thinking causes overwhelm', description: 'Too many perspectives create confusion.' },
            ],
          },
          {
            id: 'action-5-2',
            name: 'Explore new viewpoints',
            description: 'Actively seek and consider alternative perspectives.',
            transformation: 'From defending your position to genuinely exploring others.',
            obstacles: [
              { id: 'obs-5-2-1', name: 'Seeking input can feel exposing', description: 'Asking questions reveals uncertainty.' },
              { id: 'obs-5-2-2', name: 'New views can trigger resistance', description: 'Different perspectives challenge identity.' },
              { id: 'obs-5-2-3', name: 'Integration of insights takes effort', description: 'New views require active processing.' },
            ],
          },
          {
            id: 'action-5-3',
            name: 'Reframe + align',
            description: 'Transform negative narratives and align with your goals.',
            transformation: 'From stuck in limiting frames to choosing empowering ones.',
            obstacles: [
              { id: 'obs-5-3-1', name: 'Hard to shift ingrained negative narratives', description: 'Old stories have deep roots.' },
              { id: 'obs-5-3-2', name: 'Maintaining perspective consistency', description: 'New frames slip under pressure.' },
              { id: 'obs-5-3-3', name: 'Early reframes feel inauthentic', description: 'New perspectives feel forced at first.' },
            ],
          },
        ],
      },
      {
        id: 'lesson-6',
        name: 'Vision Accelerator',
        subtitle: 'Inspiration',
        description: 'Create a compelling vision of your transformed future.',
        actions: [
          {
            id: 'action-6-1',
            name: 'Explore possibilities',
            description: 'Break out of limiting boxes and imagine expanded futures.',
            transformation: 'From constrained thinking to expansive possibility.',
            obstacles: [
              { id: 'obs-6-1-1', name: 'Fear of dreaming "too big"', description: 'Big visions feel unrealistic or arrogant.' },
              { id: 'obs-6-1-2', name: 'Creative constraints from past roles', description: 'Old identities limit imagination.' },
              { id: 'obs-6-1-3', name: 'Visualizing abstract futures feels unfamiliar', description: 'Hard to picture what doesn\'t exist.' },
            ],
          },
          {
            id: 'action-6-2',
            name: 'Release impairments',
            description: 'Let go of beliefs and identities that block your vision.',
            transformation: 'From clinging to old self to making space for new possibility.',
            obstacles: [
              { id: 'obs-6-2-1', name: 'Resistance to letting go of old identities', description: 'Who you were feels safe.' },
              { id: 'obs-6-2-2', name: 'Fear of losing competence narrative', description: 'Old skills define your worth.' },
              { id: 'obs-6-2-3', name: 'Belief shifts create identity dissonance', description: 'New beliefs don\'t match old self-image.' },
            ],
          },
          {
            id: 'action-6-3',
            name: 'Envision future scenarios',
            description: 'Create detailed, values-aligned visions of your future.',
            transformation: 'From vague hopes to vivid, actionable vision.',
            obstacles: [
              { id: 'obs-6-3-1', name: 'Balancing idealism with realism', description: 'Dreams need to be achievable.' },
              { id: 'obs-6-3-2', name: 'Aligning with values takes refinement', description: 'True values require excavation.' },
              { id: 'obs-6-3-3', name: 'Translating vision into strategy is unclear', description: 'The path from here to there is foggy.' },
            ],
          },
        ],
      },
    ],
  },
  {
    id: 'phase-3',
    name: 'Stabilization',
    subtitle: 'Sustain',
    description: 'Embed your new beliefs into lasting habits and systems. This phase is about making transformation permanent and building support for continued growth.',
    color: '#F59E0B', // Amber
    lessons: [
      {
        id: 'lesson-7',
        name: 'Habit Harmonizer',
        subtitle: 'Conviction',
        description: 'Internalize your new beliefs through consistent practice.',
        actions: [
          {
            id: 'action-7-1',
            name: 'Internalize beliefs',
            description: 'Deepen new beliefs through repetition and reflection.',
            transformation: 'From intellectual understanding to embodied knowing.',
            obstacles: [
              { id: 'obs-7-1-1', name: 'Inconsistent reflection practice', description: 'Life interrupts intention.' },
              { id: 'obs-7-1-2', name: 'Lingering doubts weaken conviction', description: 'Old beliefs whisper from the shadows.' },
              { id: 'obs-7-1-3', name: 'Repeating without meaning feels empty', description: 'Rote practice loses power.' },
            ],
          },
          {
            id: 'action-7-2',
            name: 'Apply beliefs in real world',
            description: 'Test and strengthen beliefs through real-world application.',
            transformation: 'From theory to proven practice.',
            obstacles: [
              { id: 'obs-7-2-1', name: 'Real-world stress tests belief strength', description: 'Pressure reveals fragility.' },
              { id: 'obs-7-2-2', name: 'Unexpected results shake confidence', description: 'Reality doesn\'t follow the script.' },
              { id: 'obs-7-2-3', name: 'Lack of reinforcement discourages follow-through', description: 'Without support, motivation fades.' },
            ],
          },
          {
            id: 'action-7-3',
            name: 'Daily checklist',
            description: 'Create and use a daily belief sustainment checklist.',
            transformation: 'From sporadic effort to systematic practice.',
            obstacles: [
              { id: 'obs-7-3-1', name: 'Over-customization delays use', description: 'Perfect systems never start.' },
              { id: 'obs-7-3-2', name: 'Routine fatigue leads to drop-off', description: 'Novelty fades, so does commitment.' },
              { id: 'obs-7-3-3', name: 'Checklist loses relevance over time', description: 'Growth outpaces the system.' },
            ],
          },
        ],
      },
      {
        id: 'lesson-8',
        name: 'Execution Engine',
        subtitle: 'Momentum',
        description: 'Create and execute a personalized action plan.',
        actions: [
          {
            id: 'action-8-1',
            name: 'Personalize action plan',
            description: 'Design a customized plan that tests your new beliefs.',
            transformation: 'From generic goals to personalized strategy.',
            obstacles: [
              { id: 'obs-8-1-1', name: 'Too many priorities compete', description: 'Everything seems equally important.' },
              { id: 'obs-8-1-2', name: 'Over-optimizing delays action', description: 'Planning becomes procrastination.' },
              { id: 'obs-8-1-3', name: 'Unrealistic plans lead to shutdown', description: 'Overwhelm triggers avoidance.' },
            ],
          },
          {
            id: 'action-8-2',
            name: 'Predict/respond to obstacles',
            description: 'Anticipate challenges and prepare responses in advance.',
            transformation: 'From being blindsided to being prepared.',
            obstacles: [
              { id: 'obs-8-2-1', name: 'Poor anticipation causes friction', description: 'Unexpected problems derail progress.' },
              { id: 'obs-8-2-2', name: 'Solutions feel too theoretical', description: 'Plans don\'t survive contact with reality.' },
              { id: 'obs-8-2-3', name: 'Overplanning creates rigidity', description: 'Too much structure kills adaptability.' },
            ],
          },
          {
            id: 'action-8-3',
            name: 'Seek feedback',
            description: 'Engage support systems and incorporate feedback.',
            transformation: 'From isolated effort to supported growth.',
            obstacles: [
              { id: 'obs-8-3-1', name: 'Fear of judgment blocks outreach', description: 'Asking for help feels weak.' },
              { id: 'obs-8-3-2', name: 'Dismissing feedback due to pride', description: 'Ego rejects useful input.' },
              { id: 'obs-8-3-3', name: 'Support network isn\'t aligned or accessible', description: 'The right people aren\'t available.' },
            ],
          },
        ],
      },
      {
        id: 'lesson-9',
        name: 'Growth Anchor',
        subtitle: 'Perseverance',
        description: 'Build sustainable systems for ongoing growth and support.',
        actions: [
          {
            id: 'action-9-1',
            name: 'Build growth system',
            description: 'Design a sustainable framework for continued development.',
            transformation: 'From one-time change to ongoing evolution.',
            obstacles: [
              { id: 'obs-9-1-1', name: 'Hard to design adaptable structure', description: 'Systems either too rigid or too loose.' },
              { id: 'obs-9-1-2', name: 'Life integration feels disruptive', description: 'Growth competes with existing commitments.' },
              { id: 'obs-9-1-3', name: 'Progress is hard to measure', description: 'Transformation doesn\'t fit spreadsheets.' },
            ],
          },
          {
            id: 'action-9-2',
            name: 'Develop adaptability',
            description: 'Cultivate flexibility and resilience for changing circumstances.',
            transformation: 'From rigidity under stress to flow with change.',
            obstacles: [
              { id: 'obs-9-2-1', name: 'Change triggers uncertainty', description: 'The unknown activates fear.' },
              { id: 'obs-9-2-2', name: 'Flexibility is outside comfort zone', description: 'Structure feels safer than flow.' },
              { id: 'obs-9-2-3', name: 'Stress hijacks resilience', description: 'Under pressure, old patterns return.' },
            ],
          },
          {
            id: 'action-9-3',
            name: 'Circle of support',
            description: 'Build and maintain a network of growth-aligned relationships.',
            transformation: 'From going it alone to being held by community.',
            obstacles: [
              { id: 'obs-9-3-1', name: 'Trust issues limit connection', description: 'Past hurt makes opening up hard.' },
              { id: 'obs-9-3-2', name: 'Support may not match growth pace', description: 'Others grow at different speeds.' },
              { id: 'obs-9-3-3', name: 'Difficulty sustaining mutual commitment', description: 'Relationships require ongoing investment.' },
            ],
          },
        ],
      },
    ],
  },
];

// Helper to get flat list of all lessons
export function getAllLessons() {
  return IAS_CURRICULUM.flatMap(phase => phase.lessons);
}

// Helper to get flat list of all actions
export function getAllActions() {
  return IAS_CURRICULUM.flatMap(phase => 
    phase.lessons.flatMap(lesson => lesson.actions)
  );
}

// Helper to find the phase containing a lesson
export function getPhaseForLesson(lessonId: string): Phase | undefined {
  return IAS_CURRICULUM.find(phase => 
    phase.lessons.some(lesson => lesson.id === lessonId)
  );
}

// Helper to find lesson containing an action
export function getLessonForAction(actionId: string): { phase: Phase; lesson: Lesson } | undefined {
  for (const phase of IAS_CURRICULUM) {
    for (const lesson of phase.lessons) {
      if (lesson.actions.some(action => action.id === actionId)) {
        return { phase, lesson };
      }
    }
  }
  return undefined;
}
