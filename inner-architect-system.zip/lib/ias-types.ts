// Inner Architect System Types - Matches Neo4j Graph Structure

export interface Obstacle {
  id: string;
  name: string;
  description: string;
}

export interface Action {
  id: string;
  name: string;
  description: string;
  transformation: string;
  obstacles: Obstacle[];
}

export interface Lesson {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  actions: Action[];
}

export interface Phase {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  color: string;
  lessons: Lesson[];
}

export interface IASRecommendation {
  phase: Phase;
  lesson: Lesson;
  action: Action;
  reasoning: string;
  transformation: string;
}

export interface JourneyState {
  stage: 'chat' | 'phases' | 'lessons' | 'actions' | 'confirmation';
  selectedPhase?: Phase;
  selectedLesson?: Lesson;
  selectedAction?: Action;
  recommendation?: IASRecommendation;
}
